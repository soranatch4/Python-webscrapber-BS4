import requests
from bs4 import BeautifulSoup
from csv import writer
import re
import pandas as pd
import collections
from datetime import date
import datetime
from time import gmtime, strftime
import csv

print('------------------------Start----------------------')
today = datetime.datetime.now()
str_today = str(today)
df = pd.read_csv(r'page.csv')
#print(df)
dc = (df['Link'])
#print(dc)
dg = list(dc)
da = len(dg)
ds = str(da)
dt = ('Recently updated ') + ds + (' Pages : ') + str_today
print(dt)
print(' ')
#print(dg)
with open('post.csv', 'w', newline='') as csv_file:
    csv_writer = writer(csv_file)
    headers = ['page-name','page-like','page-follower']
    csv_writer.writerow(headers)

    for item in dg:
        url = item
        da = len(dg)
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        el = soup.find_all(class_='_4bl9')[1]
        data1 = str(el)
        page_like1 = re.sub('<[^>]*>',' ',data1)
        page_like = page_like1.strip()
        el2 = soup.find_all(class_='_4bl9')[2]
        data2 = str(el2)
        page_follower1 = re.sub('<[^>]*>',' ',data2)
        page_follower = page_follower1.strip()
        el3 = soup.head.title
        data3 = str(el3)
        data4 = data3.replace('- หน้าหลัก | Facebook','')
        page_name1 = re.sub('<[^>]*>',' ',data4)
        page_name = page_name1.strip()
        pagename = page_name
        pagelike = page_like
        pagefollower = page_follower
        values_page = [page_name,pagelike,pagefollower]
        csv_writer.writerow(values_page)
        print(page_name, page_like, page_follower)
    # with open('post.csv', 'w') as csv_file:
    #     csv_writer = writer(csv_file)
    #     headers = ['page-name','page-like','page-follower']
    #     csv_writer.writerow(headers)
    #     pagename = page_name
    #     pagelike = page_like
    #     pagefollower = page_follower
    #     values_page = [page_name,pagelike,pagefollower]
    #     csv_writer.writerow(values_page)
    print(page_name,page_like,page_follower)

print(' ')
print('------------------Successfully-----------------')
